package com.wipro.dao;

import org.springframework.data.repository.CrudRepository;

import com.wipro.model.Doctor;

public interface DoctorDao extends CrudRepository<Doctor, Integer> {

}
