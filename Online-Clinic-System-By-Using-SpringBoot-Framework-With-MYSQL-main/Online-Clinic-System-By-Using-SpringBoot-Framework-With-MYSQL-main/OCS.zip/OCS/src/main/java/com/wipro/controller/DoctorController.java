package com.wipro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.model.Doctor;
import com.wipro.service.DoctorService;

@Controller
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	@RequestMapping("/insertDoctorForm")
	public ModelAndView insertDoctorForm() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("doctor",new Doctor());
		mv.setViewName("DoctorForm");
		return mv;
	}
	
	
	@RequestMapping("/insertDoctor")
	public ModelAndView insertDoctor(@ModelAttribute ("doctor")Doctor doctor) {
		ModelAndView mv=new ModelAndView();
		doctorService.saveDoctor(doctor);
		mv.setViewName("redirect:displayDoctor");
		return mv;
		
	}
	
	
	@RequestMapping("/updateDoctorForm")
	public ModelAndView updateDoctorForm() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("doc",new Doctor());
		List<Doctor> doctors=doctorService.getAllDoctors();
		System.out.println(doctors);
		mv.addObject("doctors",doctors);
		mv.setViewName("UpdateDoctor");
		return mv;
	}
	
	@RequestMapping("/updateDoctor")
	public ModelAndView updateForm(@ModelAttribute("doctor")Doctor doctor) {
		ModelAndView mv=new ModelAndView();
		doctorService.updateDoctor(doctor);
		mv.setViewName("redirect:displayDoctor");
		return mv;
	}
	
	@RequestMapping("/deleteDoctorForm")
	public ModelAndView deleteDoctorForm() {
		ModelAndView mv=new ModelAndView();
		mv.addObject("doc",new Doctor());
		List<Doctor> doctors=doctorService.getAllDoctors();
		System.out.println(doctors);
		mv.addObject("doctors",doctors);
		mv.setViewName("DeleteDoctor");
		return mv;
	}
	
	@RequestMapping("/deleteDoctor")
	public ModelAndView deleteDoctor(@ModelAttribute("doctor")Doctor doctor) {
		ModelAndView mv=new ModelAndView();
		
		doctorService.deleteDoctorById(doctor.getDoctorId());
		mv.setViewName("redirect:displayDoctor");
		return mv;
	}
	
	@RequestMapping("/displayDoctor")
	public ModelAndView display() {
		ModelAndView mv=new ModelAndView();
		List<Doctor> doctors=doctorService.getAllDoctors();
		System.out.println(doctors);
		mv.addObject("doctors",doctors);
		mv.setViewName("ShowDoctor");
		return mv;
		
	}
	
	@RequestMapping("/showAdmin")
	public ModelAndView showAdmin() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("AdminHomePage");
		return mv;
		
	}
	
	

}
