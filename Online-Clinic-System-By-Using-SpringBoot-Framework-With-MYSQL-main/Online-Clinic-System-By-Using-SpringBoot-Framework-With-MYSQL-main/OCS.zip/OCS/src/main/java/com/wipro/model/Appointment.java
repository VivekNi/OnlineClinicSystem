package com.wipro.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
public class Appointment {

	@Id
	
	long appointmentId;

	@NotBlank(message = "UserId Cannot be empty")
	@Size(min = 8, max = 20, message = "Username contains 8-20 characters")
	String userId;

	int doctorId;

	@NotBlank(message = "Name cannot be Empty")
	@Size(min = 3, max = 25, message = "Name contains should contains 3-25 character")
	String fullname;

	
	int age;

	@NotBlank(message = "Enter your gender")
	String gender;

	@NotBlank(message = "Fill that symptoms")
	String symptom;

	Date appointmentDate;

	String appointmentTime;

	public long getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(long appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getSymptom() {
		return symptom;
	}

	public void setSymptom(String symptom) {
		this.symptom = symptom;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public String getAppointmentTime() {
		return appointmentTime;
	}

	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	@Override
	public String toString() {
		return "Appointment [appointmentId=" + appointmentId + ", userId=" + userId + ", doctorId=" + doctorId
				+ ", fullname=" + fullname + ", age=" + age + ", gender=" + gender + ", symptom=" + symptom
				+ ", appointmentDate=" + appointmentDate + ", appointmentTime=" + appointmentTime + "]";
	}

	public Appointment(long appointmentId,
			@NotBlank(message = "UserId Cannot be empty") @Size(min = 8, max = 20, message = "Username contains 8-20 characters") String userId,
			int doctorId,
			@NotBlank(message = "Name cannot be Empty") @Size(min = 3, max = 25, message = "Name contains should contains 3-25 character") String fullname,
			int age, @NotBlank(message = "Enter your gender") String gender,
			@NotBlank(message = "Fill that symptoms") String symptom, Date appointmentDate, String appointmentTime) {
		super();
		this.appointmentId = appointmentId;
		this.userId = userId;
		this.doctorId = doctorId;
		this.fullname = fullname;
		this.age = age;
		this.gender = gender;
		this.symptom = symptom;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
	}

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	

}
