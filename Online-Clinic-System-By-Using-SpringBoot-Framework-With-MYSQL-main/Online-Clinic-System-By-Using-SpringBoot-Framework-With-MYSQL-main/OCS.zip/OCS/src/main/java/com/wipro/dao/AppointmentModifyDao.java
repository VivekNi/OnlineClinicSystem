package com.wipro.dao;

import java.util.List;

import com.wipro.model.Appointment;

public interface AppointmentModifyDao {
	List<Appointment> getAppointment(int doctorId);

}
